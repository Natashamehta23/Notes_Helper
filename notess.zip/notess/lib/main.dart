import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_plugin_pdf_viewer/flutter_plugin_pdf_viewer.dart';

void main(){
  runApp(
    MaterialApp(
      home: HomePage(),
    )
    );
}
class Entry{
  const Entry(this.ttitle,[this.childrenn=const <Entry>[]]);
  final String ttitle;
  final List<Entry> childrenn;
}
const List<Entry> data=<Entry>[
  Entry(
    'Subjects',
    <Entry>[
      Entry('Artificial Intelligence'),
      Entry('Web Technologies'),
      Entry('Compiler Design'),
      Entry('Operating System'),
      Entry('Computer Networks'),
      Entry('Microprocessors and Microcontrollers'),
    ],
  ),
];
class ExpansionTile extends StatelessWidget {
  const ExpansionTile({Key key, Text title, List<Widget> children}) : super(key:key);
  @override
   Widget build(BuildContext context) {
      ListView.builder(itemBuilder: (BuildContext context, int i)=>EntryItem(data[i]),
       itemCount: data.length);
   }
}
class EntryItem extends StatelessWidget {
  const EntryItem(this.entry);
  final Entry entry;
  
  Widget _buildTiles(Entry root) {
    if(root.childrenn.isEmpty) return ListTile(title: Text(root.ttitle));
    return ExpansionTile(
      key: PageStorageKey<Entry>(root),
      title: Text(root.ttitle),
      children: root.childrenn.map(_buildTiles).toList(),
    );
  }
  @override 
  Widget build(BuildContext context){
    return _buildTiles(entry);
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String pdfasset = "assets/The Fault in Our Stars by Green John.pdf";
  PDFDocument _doc;
  bool _loading;
  @override
  void initState() {
    super.initState();
    _initPdf();
  }
  _initPdf() async{
    final doc= await PDFDocument.fromAsset(pdfasset);
    setState(() {
      _loading = true;
    });
      setState(() {
        _loading = false;
      });
      
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.purple,
        title: Text("Notes App"),
        actions: <Widget>[
          IconButton(icon: Icon(Icons.search,color: Colors.white,), onPressed: null)
        ],
        ),
        body: _loading ? Center(child: CircularProgressIndicator(),) : PDFViewer(document: _doc,),
      drawer: Drawer(
        child: ListView(
          children: <Widget>[

            UserAccountsDrawerHeader(accountName: Text("Natasha Mehta"),
             accountEmail: Text("mehtanatasha23@gmail.com"),
             currentAccountPicture: GestureDetector(
               child: CircleAvatar(
                 backgroundColor: Colors.purple,
                child:Icon(Icons.person,),
             ),), 
            ),
          InkWell (onTap: (){},
                  child: ListTile(
                title:Text("Subjects"),
                leading: Icon(Icons.book,
                color: Colors.purple,),
               ),
               ),

                InkWell (onTap: (){},
             child: ListTile(
               title:Text("Video Tutorials"),
               leading: Icon(Icons.video_library,
               color: Colors.purple,),
               trailing: Icon(Icons.arrow_forward),
               ),
               ),

                InkWell (onTap: (){},
             child: ListTile(
               title:Text("About Us"),
               leading: Icon(Icons.help,
               color: Colors.purple,),
               trailing: Icon(Icons.arrow_forward),
               ),
               ),
          ],
        )
      ),
    );
  }
}